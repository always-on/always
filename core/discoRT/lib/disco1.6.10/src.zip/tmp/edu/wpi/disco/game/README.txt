This directory contains example for building games using Disco.  For a complete game, see
the secrets project, distributed with Disco.

 		