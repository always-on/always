package edu.wpi.disco;

import edu.wpi.cetask.ShellWindow;

import java.awt.event.*;

public class ConsoleWindow extends ShellWindow {

   private final Interaction interaction;
   
   public ConsoleWindow (final Interaction interaction, int width, int height, int fontSize) {
      this(interaction, width, height, fontSize, false);
   }

   public ConsoleWindow (final Interaction interaction, int width, int height, int fontSize,
                         boolean append) {
      super(new Console(null, interaction), width, height, fontSize, append);
      this.interaction = interaction;
      setTitle("Disco");
      appendOutput(System.lineSeparator());
      interaction.setDaemon(true);
      addWindowListener(new WindowAdapter() {
         @Override
         public void windowClosed (WindowEvent e) { interaction.interrupt(); }
      });
      interaction.start(true);
   }
   
   @Override
   public void setTitle (String title) {
      super.setTitle(title);
      if ( interaction != null)
         interaction.setName(title+" ConsoleWindow");
   }
}
