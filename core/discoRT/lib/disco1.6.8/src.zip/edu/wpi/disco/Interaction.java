/* Copyright (c) 2009 Charles Rich and Worcester Polytechnic Institute.
 * All Rights Reserved.  Use is subject to license terms.  See the file
 * "license.terms" for information on usage and redistribution of this
 * file and for a DISCLAIMER OF ALL WARRANTIES.
 */
package edu.wpi.disco;

import edu.wpi.cetask.*;
import edu.wpi.disco.Agenda.Plugin;

import java.util.List;

/**
 * Class for managing a turn-based collaborative discourse interaction between two
 * actors. Note that this class is basically symmetric between the two actors.  Furthermore,
 * multiple instances of this class involving overlapping actors could be created.   
 * <p>
 * Interaction with the "environment" is typically handled by scripts associated with
 * tasks.
 */
public class Interaction extends Thread {
  
   private final Actor system, external; 
   
   /**
    * Return the actor modeled as external=false in task model.
    */
   public Actor getSystem () { return system; }
   
   /**
    * Return the actor modeled as external=true in task model.
    */
   public Actor getExternal () { return external; }

   /**
    * Return other actor in this interaction (may return null).
    */
   public Actor getOther (Actor who) { return who == system ? external : system; }

   private final Disco disco;
   
   /**
    * Return shared collaborative discourse model for this interaction.
    */
   public Disco getDisco () { return disco; }
   
   private Console console; // optional console
   
   public Console getConsole () { return console; }
   
   public void setConsole (Console console) { this.console = console; }
   
   private boolean responded;  // see doTurn
   
   // factorization to support game (typically used in dialogue loop)
   public synchronized Plan doneOccurrence (boolean external, Task occurrence, Plan contributes) {
      responded = true;
      return disco.done(external, occurrence, contributes);
   }
   
   // typically used in dialogue loop
   public synchronized void done (boolean external, Task occurrence, Plan contributes) {
      doneOccurrence(external, occurrence, contributes);
      if ( console != null ) console.done(occurrence);
   }

   /**
    * Choose given item number (starting with 1) in given list of plugin items for utterances
    * and execute it.
    */
   public void choose (List<Plugin.Item> items, int i, String formatted) {
      if ( i > 0 && i <= items.size() ) {
         Plugin.Item item = items.get(i-1);
         // make sure history shows same alternative as menu selection
         disco.doneUtterance(item.task, formatted);
         done(true, item.task, item.contributes);
      } else throw new IndexOutOfBoundsException();
   }
   
   private boolean externalFloor; // true iff external has floor
   
   /**
    * Return the actor who currently has the turn (may be null ).
    */
   public Actor getFloor () { return externalFloor ? external : system; }
   
   // NB all read/write to discourse state on this single thread

   protected boolean running;
   
   @Override
   public void run () {
      if ( (system == null || external == null) && console == null )
         throw new IllegalStateException("Need console for missing user or agent!");
      boolean first = true;
      // this is the turn-taking loop
      while (running) {
         if ( !doTurn(first) ) break;
         first = false;
      }
      cleanup();
   }
   
   private boolean ok = true, guess = true;
   
   /**
    * Default value for interaction@ok property
    */
   public void setOk (boolean ok) { this.ok = ok; }

   /**
    * Set default value for interaction@ok property
    */
   public boolean isOk () { return ok; }
   
   /**
    * Default value for interaction@guess property
    */
   public void setGuess (boolean guess) { this.guess = guess; }

   /**
    * Set default value for interaction@guess property
    */
   public boolean isGuess () { return guess; }
   
   /**
    * Perform one turn of interaction.
    * 
    * @param first true if this is first turn
    * @return true iff interaction should continue running
    */
   public boolean doTurn (boolean first) {
      Actor floor = getFloor();
      responded = false;
      boolean ok = disco.getProperty("interaction@ok", this.ok);
      if ( floor != null ) 
         floor.respond(this, ok, disco.getProperty("interaction@guess", guess));
      if ( !running ) return false;
      if ( console != null && (first || responded || (!ok && !externalFloor)) ) 
         console.respond(this);
      externalFloor = !externalFloor;
      return true;
   }
   
   /**
    * Create an interaction with a console for debugging.  Note this creates a new
    * instance of Disco for this interaction.
    * 
    * @param from url or filename from which to read console commands (for testing),
    *        or null
    * 
    * @see #Interaction(Actor,Actor)
    */
   public Interaction (Actor system, Actor external, String from) {
      this(system, external);
      console = new Console(from, this);
      console.init(disco);
   }
   
   /**
    * Create an interaction and associated discourse model between given actors.
    * Note this creates a new instance of Disco for this interaction.
    * 
    * @param system - actor which is modeled as external=false in task model 
    * @param external - actor which is modeled as external=true in task model
    */
   public Interaction (Actor system, Actor external) {
      super("edu.wpi.disco.Interaction");
      this.system = system;
      this.external = external;
      this.disco = new Disco(this);
      if ( system != null ) system.init(disco); 
      if ( external != null ) external.init(disco); 
      setUncaughtExceptionHandler(
            new Thread.UncaughtExceptionHandler() {
               @Override
               public void uncaughtException (Thread t, Throwable e) {
                  Interaction.this.cleanup();
                  t.getThreadGroup().uncaughtException(t, e);
               }
            });
   }
   
   /**
    * Start the interaction with specified actor's turn.  Runs on separate thread.
    * 
    * @param externalFloor true iff user gets floor first.
    */
   public void start (boolean externalFloor) {
      this.externalFloor = externalFloor;
      running = true;
      start();
   }

   /**
    * Clear any discourse state information stored in this interaction.  
    */
   public void clear () { 
      disco.clear();
      system.clear(this); 
      external.clear(this); 
   }
   
   /**
    * Stop this interaction thread.
    */
   public void exit () { running = false; }
   
   /**
    * Method to cleanup (free resources, etc.) when this interaction thread exits.
    * Calls cleanup on two actors.
    */
   public void cleanup () {
      if ( system != null ) system.cleanup(this); 
      if ( external!= null ) external.cleanup(this);
      if ( console != null ) console.cleanup();
   }
}